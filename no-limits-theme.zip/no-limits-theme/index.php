<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and is required for the theme to work.
 *
 * @package No_Limits
 */

get_header();
?>

<main id="primary" class="site-main">
    
    <?php if (is_front_page() && !is_paged()) : ?>
    <!-- Hero Section -->
    <section class="hero">
        <h1 class="hero-title melting-text">NO LIMITS BEYOND LIMITATIONS</h1>
        <p class="hero-subtitle">Into My Wildest Imagination</p>
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="btn-primary">Shop Now</a>
    </section>
    <?php endif; ?>
    
    <?php if (is_woocommerce()) : ?>
        <?php woocommerce_content(); ?>
    <?php else : ?>
    
    <?php if (have_posts()) : ?>
        
        <?php if (is_home() && !is_front_page()) : ?>
            <section class="products-section">
                <h2 class="section-title"><?php single_post_title(); ?></h2>
            </section>
        <?php endif; ?>
        
        <div class="products-grid">
            <?php
            /* Start the Loop */
            while (have_posts()) :
                the_post();
                
                /*
                 * Include the Post-Format-specific template for the content.
                 * If you want to override this in a child theme, then include a file
                 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                 */
                get_template_part('template-parts/content', get_post_format());
                
            endwhile;
            ?>
        </div>
        
        <?php
        // Pagination
        the_posts_pagination(array(
            'prev_text' => __('&larr; Previous', 'no-limits'),
            'next_text' => __('Next &rarr;', 'no-limits'),
            'before_page_number' => '<span class="meta-nav screen-reader-text">',
            'after_page_number'  => '</span>',
        ));
        
        else :
            
            get_template_part('template-parts/content', 'none');
            
        endif;
        
        endif;
        ?>
        
</main><!-- #primary -->

<?php
get_footer();
