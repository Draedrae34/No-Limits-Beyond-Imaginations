<?php
/**
 * The footer for our theme
 *
 * @package No_Limits
 */

?>

<footer class="site-footer">
    <div class="footer-content">
        <div class="footer-logo">
            <h3>No Limits Beyond Limitations</h3>
        </div>
        
        <div class="footer-links">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'footer',
                'menu_id'        => 'footer-menu',
                'fallback_cb'    => false,
            ));
            ?>
        </div>
        
        <div class="footer-info">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
            <p>Galaxy-themed merchandise with free shipping on your first order!</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>
