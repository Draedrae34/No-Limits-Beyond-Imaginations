/**
 * No Limits Theme Main JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // ==================== NAVIGATION ====================
    $('.main-navigation ul li a').hover(
        function() {
            $(this).css('background', 'linear-gradient(45deg, #ff69b4, #9370db)');
        },
        function() {
            $(this).css('background', 'transparent');
        }
    );
    
    // ==================== ADD TO CART ====================
    $('.btn-add-to-cart').on('click', function(e) {
        e.preventDefault();
        
        var productId = $(this).data('product-id');
        var quantity = $(this).data('quantity') || 1;
        
        if (productId) {
            $.ajax({
                url: noLimitsAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'no_limits_ajax_add_to_cart',
                    product_id: productId,
                    quantity: quantity,
                    nonce: noLimitsAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        // Update cart count
                        $('.cart-count').text(response.data.cart_count);
                    }
                },
                error: function() {
                    alert('Failed to add product to cart. Please try again.');
                }
            });
        }
    });
    
    // ==================== PRODUCT HOVER EFFECTS ====================
    $('.product-card').hover(
        function() {
            $(this).css('transform', 'translateY(-10px)');
            $(this).css('box-shadow', '0 20px 40px rgba(255, 105, 180, 0.3)');
        },
        function() {
            $(this).css('transform', 'translateY(0)');
            $(this).css('box-shadow', '');
        }
    );
    
    // ==================== MELTING TEXT EFFECT ====================
    $('.melting-text').css('animation', 'melt 2s infinite');
    
    // ==================== QUANTITY INPUTS ====================
    $('.quantity input').on('change', function() {
        $(this).closest('form').trigger('submit');
    });
    
    // ==================== SEARCH FORM ====================
    $('.search-form').on('submit', function(e) {
        var searchTerm = $(this).find('input[type="search"]').val();
        if (!searchTerm.trim()) {
            e.preventDefault();
            alert('Please enter a search term.');
        }
    });
    
    // ==================== LAZY LOAD IMAGES ====================
    $('img[data-src]').each(function() {
        var img = $(this);
        img.attr('src', img.data('src')).removeAttr('data-src');
    });
    
    // ==================== SMOOTH SCROLL ====================
    $('a[href^="#"]').on('click', function(e) {
        var target = $($(this).attr('href'));
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 500);
        }
    });
    
    // ==================== LOADING ANIMATION ====================
    $('.btn-primary, .btn-add-to-cart').on('click', function() {
        var btn = $(this);
        var originalText = btn.text();
        btn.html('<span class="loading-dots"><span></span><span></span><span></span></span>');
        
        setTimeout(function() {
            btn.text(originalText);
        }, 2000);
    });
    
    // ==================== MOBILE MENU TOGGLE ====================
    $('.menu-toggle').on('click', function() {
        $('.main-navigation ul').slideToggle(300);
    });
    
    // ==================== WOOCOMMERCE CUSTOMIZATIONS ====================
    // Update cart fragment on add to cart
    $(document.body).on('added_to_cart', function() {
        alert('Product added to cart!');
    });
    
    // ==================== FORM VALIDATION ====================
    $('form').on('submit', function(e) {
        var requiredFields = $(this).find('[required]');
        var isValid = true;
        
        requiredFields.each(function() {
            if (!$(this).val().trim()) {
                isValid = false;
                $(this).css('border-color', '#ff0000');
            } else {
                $(this).css('border-color', '');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            alert('Please fill in all required fields.');
        }
    });
    
    // ==================== SCROLL TO TOP ====================
    var scrollTopBtn = $('#scroll-top');
    
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            scrollTopBtn.fadeIn();
        } else {
            scrollTopBtn.fadeOut();
        }
    });
    
    scrollTopBtn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 500);
    });
    
    // ==================== ANIMATE ON SCROLL ====================
    $('.product-card').css('opacity', '0');
    
    $(window).on('scroll', function() {
        $('.product-card').each(function(i) {
            var element = $(this);
            var position = element.offset().top;
            var scroll = $(window).scrollTop();
            var windowHeight = $(window).height();
            
            if (position < scroll + windowHeight - 100) {
                setTimeout(function() {
                    element.animate({
                        opacity: '1',
                        transform: 'translateY(0)'
                    }, 400);
                }, i * 100);
            }
        });
    });
    
    // Trigger scroll event on load
    $(window).trigger('scroll');
    
    // ==================== NEWSLETTER FORM ====================
    $('.newsletter-form').on('submit', function(e) {
        e.preventDefault();
        var email = $(this).find('input[type="email"]').val();
        
        if (email && email.includes('@')) {
            alert('Thank you for subscribing! You\'ll receive galaxy-themed updates.');
            $(this).find('input[type="email"]').val('');
        } else {
            alert('Please enter a valid email address.');
        }
    });
    
    // ==================== SOCIAL SHARE ====================
    $('.share-btn').on('click', function(e) {
        e.preventDefault();
        var network = $(this).data('network');
        var url = encodeURIComponent(window.location.href);
        var text = encodeURIComponent(document.title);
        
        var shareUrls = {
            'facebook': 'https://www.facebook.com/sharer/sharer.php?u=' + url,
            'twitter': 'https://twitter.com/intent/tweet?url=' + url + '&text=' + text,
            'pinterest': 'https://pinterest.com/pin/create/button/?url=' + url
        };
        
        if (shareUrls[network]) {
            window.open(shareUrls[network], '_blank', 'width=600,height=400');
        }
    });
    
    // ==================== QUICK VIEW ====================
    $('.quick-view-btn').on('click', function(e) {
        e.preventDefault();
        var productId = $(this).data('product-id');
        
        // Could implement modal popup with product details
        alert('Quick view for product #' + productId);
    });
    
    // ==================== FILTER TOGGLES ====================
    $('.filter-toggle').on('click', function() {
        $('.product-filters').slideToggle(300);
        $(this).text($(this).text() === 'Show Filters' ? 'Hide Filters' : 'Show Filters');
    });
    
    // ==================== GRID LIST VIEW TOGGLE ====================
    $('.view-toggle .grid-view').on('click', function() {
        $('.products-grid').removeClass('list-view').addClass('grid-view');
        $(this).addClass('active');
        $('.list-view').removeClass('active');
    });
    
    $('.view-toggle .list-view').on('click', function() {
        $('.products-grid').removeClass('grid-view').addClass('list-view');
        $(this).addClass('active');
        $('.grid-view').removeClass('active');
    });
    
    // Console log for debugging
    console.log('No Limits Theme loaded successfully!');
    
}); // End jQuery
