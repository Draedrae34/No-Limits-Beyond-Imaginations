<?php
/**
 * The header for our theme
 *
 * @package No_Limits
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class('no-limits-theme'); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="site-logo">
        <?php
        if (has_custom_logo()) {
            the_custom_logo();
        } else {
            echo '<a href="' . esc_url(home_url('/')) . '">';
            echo '<img src="' . get_template_directory_uri() . '/images/logo.png" alt="' . esc_attr(get_bloginfo('name')) . '">';
            echo '</a>';
        }
        ?>
    </div>
    
    <nav class="main-navigation">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_id'        => 'primary-menu',
            'fallback_cb'    => 'wp_page_menu',
        ));
        ?>
    </nav>
    
    <div class="header-actions">
        <?php if (function_exists('woocommerce_header_cart')) : ?>
            <?php woocommerce_header_cart(); ?>
        <?php endif; ?>
    </div>
</header>
