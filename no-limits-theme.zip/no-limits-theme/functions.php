<?php
/**
 * No Limits Beyond Limitations Theme Functions
 * 
 * This theme integrates WooCommerce and provides custom functionality
 * for the No Limits Clothing online store.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function no_limits_setup() {
    // Add title tag support
    add_theme_support('title-tag');
    
    // Add featured image support
    add_theme_support('post-thumbnails');
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Add HTML5 support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'no-limits'),
        'footer'  => __('Footer Menu', 'no-limits'),
    ));
}
add_action('after_setup_theme', 'no_limits_setup');

/**
 * Enqueue Styles and Scripts
 */
function no_limits_scripts() {
    // Main stylesheet
    wp_enqueue_style('no-limits-style', get_stylesheet_uri());
    
    // Google Fonts
    wp_enqueue_style('no-limits-fonts', 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;500;700&display=swap');
    
    // Custom JavaScript
    wp_enqueue_script('no-limits-script', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0', true);
    
    // Localize script for AJAX
    wp_localize_script('no-limits-script', 'noLimitsAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('no_limits_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'no_limits_scripts');

/**
 * WooCommerce Support
 */
function no_limits_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'no_limits_woocommerce_support');

/**
 * Remove WooCommerce Default Styles (optional)
 */
function dequeue_woocommerce_styles() {
    if (!is_woocommerce()) {
        wp_dequeue_style('woocommerce-general');
        wp_dequeue_style('woocommerce-layout');
    }
}
add_action('wp_enqueue_scripts', 'dequeue_woocommerce_styles', 99);

/**
 * Custom WooCommerce Product Loop Items
 */
function no_limits_woocommerce_product_loop_item() {
    global $product;
    
    $image = woocommerce_get_product_thumbnail('woocommerce_thumbnail');
    $title = get_the_title();
    $price = $product->get_price_html();
    $link = get_permalink();
    
    echo '<div class="product-card">';
    echo '<a href="' . esc_url($link) . '">' . $image . '</a>';
    echo '<h3 class="melting-text"><a href="' . esc_url($link) . '">' . esc_html($title) . '</a></h3>';
    echo '<div class="price">' . $price . '</div>';
    echo '<button class="btn-add-to-cart" onclick="window.location.href=\'' . esc_url($link) . '\'">View Product</button>';
    echo '</div>';
}

/**
 * AJAX Add to Cart Handler
 */
function no_limits_ajax_add_to_cart() {
    check_ajax_referer('no_limits_nonce', 'nonce');
    
    $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? absint($_POST['quantity']) : 1;
    
    if ($product_id && WC()->cart->add_to_cart($product_id, $quantity)) {
        wp_send_json_success(array(
            'message' => 'Product added to cart',
            'cart_count' => WC()->cart->get_cart_contents_count(),
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to add product'));
    }
}
add_action('wp_ajax_no_limits_ajax_add_to_cart', 'no_limits_ajax_add_to_cart');
add_action('wp_ajax_nopriv_no_limits_ajax_add_to_cart', 'no_limits_ajax_add_to_cart');

/**
 * Custom Checkout Fields (if needed)
 */
function no_limits_checkout_fields($fields) {
    // Customize checkout fields here
    return $fields;
}
add_filter('woocommerce_checkout_fields', 'no_limits_checkout_fields');

/**
 * Add Custom Body Classes
 */
function no_limits_body_classes($classes) {
    $classes[] = 'no-limits-theme';
    
    if (is_woocommerce()) {
        $classes[] = 'woocommerce-page';
    }
    
    return $classes;
}
add_filter('body_class', 'no_limits_body_classes');

/**
 * Register Sidebar
 */
function no_limits_widgets_init() {
    register_sidebar(array(
        'name'          => __('Main Sidebar', 'no-limits'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'no-limits'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'no_limits_widgets_init');

/**
 * Custom Excerpt Length
 */
function no_limits_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'no_limits_excerpt_length');

/**
 * Custom Excerpt More
 */
function no_limits_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'no_limits_excerpt_more');

/**
 * Disable WordPress Admin Bar for non-admins
 */
function no_limits_disable_admin_bar() {
    if (!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}
add_action('after_setup_theme', 'no_limits_disable_admin_bar');

/**
 * Custom Login Logo
 */
function no_limits_login_logo() {
    ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php echo get_template_directory_uri(); ?>/images/logo.png);
            background-size: contain;
            background-repeat: no-repeat;
            width: 200px;
            height: 60px;
        }
    </style>
    <?php
}
add_action('login_head', 'no_limits_login_logo');

/**
 * Custom Login Logo URL
 */
function no_limits_login_logo_url() {
    return home_url();
}
add_filter('login_headerurl', 'no_limits_login_logo_url');

/**
 * Custom Login Logo Title
 */
function no_limits_login_logo_title() {
    return get_bloginfo('name');
}
add_filter('login_headertext', 'no_limits_login_logo_title');
