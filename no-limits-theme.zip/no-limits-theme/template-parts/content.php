<?php
/**
 * The template for displaying content
 *
 * @package No_Limits
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('product-card'); ?>>
    <?php if (has_post_thumbnail()) : ?>
        <a href="<?php the_permalink(); ?>">
            <?php the_post_thumbnail('woocommerce_thumbnail'); ?>
        </a>
    <?php endif; ?>
    
    <h3 class="melting-text">
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h3>
    
    <div class="entry-content">
        <?php the_excerpt(); ?>
    </div>
    
    <footer class="entry-footer">
        <?php
        $price = get_post_meta(get_the_ID(), '_price', true);
        if ($price) {
            echo '<span class="price">' . wc_price($price) . '</span>';
        }
        ?>
        <a href="<?php the_permalink(); ?>" class="btn-add-to-cart">View Details</a>
    </footer>
</article>
